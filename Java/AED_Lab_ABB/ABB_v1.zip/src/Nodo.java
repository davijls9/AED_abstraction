public class Nodo {
     Aluno meuAluno;

     public Nodo(Aluno novo){
         meuAluno = novo;
     }
}
