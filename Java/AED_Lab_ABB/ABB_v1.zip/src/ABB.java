

public class ABB {
    Nodo raiz;
    ABB subarvoreEsquerda;
    ABB subarvoreDireita;

    public ABB(Aluno quem){
        raiz = new Nodo(quem);
        subarvoreDireita = null;
        subarvoreEsquerda = null;
    }

    public ABB inserir(Aluno novo, ABB subarvore){
         if(subarvore == null){
             ABB novaSubarvore = new ABB(novo);
             return novaSubarvore;
         }   
         else{
            if(novo.ehMenorQue(subarvore.raiz.meuAluno))
                  subarvore.subarvoreEsquerda = inserir(novo, subarvore.subarvoreEsquerda);
            else
                  subarvore.subarvoreDireita =  inserir(novo, subarvore.subarvoreDireita);
            
            return subarvore;
         }    
    }

    public Aluno buscar(Aluno quem, ABB subarvore){
        if(subarvore == null){
            return null;
        }
        else{
            if(quem.igual(subarvore.raiz.meuAluno))
                return subarvore.raiz.meuAluno;
            else
                if(quem.ehMenorQue(subarvore.raiz.meuAluno))
                    return buscar(quem, subarvore.subarvoreEsquerda);
                else
                    return buscar(quem, subarvore.subarvoreDireita);
        }
    }

    public String dadosArvore(ABB subarvore){
        if(subarvore == null)
            return "";
        else{
            String aux = dadosArvore(subarvore.subarvoreEsquerda);
            aux += subarvore.raiz.meuAluno.dadosAluno();
            aux += dadosArvore(subarvore.subarvoreDireita);
            return aux;
        }
    }


}
