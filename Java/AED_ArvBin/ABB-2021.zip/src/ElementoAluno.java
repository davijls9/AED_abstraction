public class ElementoAluno {
     Aluno dado;

     public ElementoAluno(Aluno quem){
         dado = quem;
     }
}
